# Aetherion History para Android

Proyecto Android sencillo que muestra https://aetherionhistory.netlify.app/ dentro de una WebView.

## Requisitos
- Android Studio actualizado.
- JDK 17 (normalmente incluido con Android Studio).
- SDK de Android 35 instalado desde SDK Manager.
- Conexión a Internet en el dispositivo para cargar la web.

## Generar el APK instalable
1. Descomprime `AetherionHistoryAndroid.zip`.
2. Abre Android Studio y selecciona **Open**; elige la carpeta `AetherionHistoryAndroid`.
3. Acepta la sincronización de Gradle e instala los componentes que Android Studio solicite.
4. En el menú **Build**, selecciona **Build Bundle(s) / APK(s) > Build APK(s)**.
5. Al terminar, Android Studio mostrará un enlace para localizar el APK. La ruta habitual es `app/build/outputs/apk/debug/app-debug.apk`.
6. Copia el APK al teléfono Android y ábrelo para instalarlo. Es posible que Android solicite autorizar instalaciones desde esa fuente.

## Notas
- La aplicación requiere Internet y no funciona como copia sin conexión de la web.
- JavaScript y almacenamiento DOM están habilitados porque muchas webs modernas los necesitan.
- Los enlaces del propio dominio se mantienen dentro de la aplicación; enlaces externos se abren con otra aplicación compatible.
- Nombre visible: **Aetherion History**.
- ID de aplicación: `com.aetherionhistory.app`.
- Antes de distribuirla, prueba inicio de sesión, formularios, enlaces, audio/vídeo y cualquier función específica de la web en un dispositivo real.
